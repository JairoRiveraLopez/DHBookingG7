package Grupo7.DHBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DhBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
