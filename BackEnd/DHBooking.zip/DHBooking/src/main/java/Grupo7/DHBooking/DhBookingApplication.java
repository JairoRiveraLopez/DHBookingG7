package Grupo7.DHBooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DhBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DhBookingApplication.class, args);
	}

}
